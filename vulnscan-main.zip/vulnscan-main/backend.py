#!/usr/bin/env python3
import json, sys, subprocess, urllib.request, urllib.parse, time, re, socket, ssl
import xml.etree.ElementTree as ET
from datetime import datetime

# ─── TOR / PROXY CONFIGURATION ───────────────
# All external connections are routed through Tor (SOCKS5 on 127.0.0.1:9050)
# nmap uses proxychains; Python HTTP uses urllib via SOCKS5 proxy handler

TOR_SOCKS_HOST = "127.0.0.1"
TOR_SOCKS_PORT = 9050

def get_tor_opener():
    """
    Returns a urllib opener that routes through Tor SOCKS5.
    Requires: pip3 install PySocks --break-system-packages
    Falls back to direct if PySocks not available.
    """
    try:
        import socks
        import socket as _socket
        # Monkey-patch socket for this process
        socks.set_default_proxy(socks.SOCKS5, TOR_SOCKS_HOST, TOR_SOCKS_PORT)
        _socket.socket = socks.socksocket
        return urllib.request.build_opener()
    except ImportError:
        print("[!] PySocks not installed — HTTP requests won't use Tor.", file=sys.stderr)
        print("[!] Fix: pip3 install PySocks --break-system-packages", file=sys.stderr)
        return urllib.request.build_opener()

# Build the Tor opener once at module load
_tor_opener = None
def tor_opener():
    global _tor_opener
    if _tor_opener is None:
        _tor_opener = get_tor_opener()
    return _tor_opener

def tor_urlopen(url, headers=None, timeout=30, data=None):
    """
    Open a URL through Tor. Wraps urllib with SOCKS5 proxy and custom headers.
    """
    req = urllib.request.Request(url, data=data)
    req.add_header("User-Agent", "Mozilla/5.0 VulnScanner/2.0")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        # Try to use socks-patched socket
        opener = tor_opener()
        return opener.open(req, timeout=timeout)
    except Exception:
        # Fallback to standard urlopen
        return urllib.request.urlopen(req, timeout=timeout, context=ctx)


# ─── NMAP PORT SCAN (via proxychains) ─────────
# IMPORTANT NOTES FOR TOR/PROXYCHAINS SCANNING:
#   - Must use -sT (TCP connect) — SYN scans don't work through proxychains
#   - Must use -Pn (skip ping) — ICMP doesn't work through Tor
#   - Reduced port range (top 1000) for speed — full range would timeout
#   - Increased timeout values to handle Tor latency (~300–2000ms per hop)
#   - Removed version intensity to reduce connection count
#   - Results may be partial — Tor exit nodes sometimes block ports

def run_nmap_scan(target):
    """
    Runs nmap through proxychains (Tor).
    Uses TCP connect scan with conservative timing for proxy reliability.
    """
    try:
        cmd = [
            "proxychains4", "-q",   # -q = quiet mode, suppress proxychains output
            "nmap",
            "-sT",                   # TCP connect scan (REQUIRED for proxychains)
            "-Pn",                   # Skip host discovery (REQUIRED — ICMP blocked by Tor)
            "-n",                    # No DNS resolution (faster, avoids DNS leaks)
            "--open",                # Only show open ports
            "-T2",                   # Timing: polite — avoids timeouts through Tor
                                     # T1=sneaky, T2=polite, T3=normal(default), T4=aggressive
            "--host-timeout", "300s",# Abort host after 5 min (Tor is slow)
            "--max-retries", "1",    # Only retry once — retries waste time on proxies
            "--min-rtt-timeout", "500ms",
            "--max-rtt-timeout", "10000ms",  # Up to 10s per probe (Tor latency)
            "--initial-rtt-timeout", "2000ms",
            "-sV",                   # Version detection
            "--version-intensity", "2",  # Light version detection (fewer probes = faster)
            "--top-ports", "200",    # Scan top 200 ports instead of 1-10000
                                     # Full range through Tor would take 30+ minutes
            "-oX", "-",             # XML output to stdout
            target
        ]

        print(f"[*] Starting proxychains nmap scan on: {target}", file=sys.stderr)
        print(f"[*] Note: Tor routing active — scan may take 3–10 minutes", file=sys.stderr)

        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=600   # 10 minute timeout for full Tor scan
        )

        if r.returncode != 0 and not r.stdout.strip():
            stderr = r.stderr.strip()[:500]
            # Check for common proxychains errors
            if "proxychains" in stderr.lower() or "can't assign" in stderr.lower():
                return {"error": f"proxychains error: {stderr}. Make sure proxychains4 is installed and Tor is running on port {TOR_SOCKS_PORT}."}
            return {"error": f"nmap error (exit {r.returncode}): {stderr}"}

        if not r.stdout.strip():
            return {"error": "nmap produced no output — target may be unreachable through Tor, or Tor is not running"}

        return parse_nmap_xml(r.stdout)

    except subprocess.TimeoutExpired:
        return {"error": "Scan timed out after 10 minutes. Through Tor this is normal for large ranges. Try a specific IP or reduce scope."}
    except FileNotFoundError as e:
        missing = "proxychains4" if "proxychains" in str(e) else "nmap"
        return {"error": f"{missing} not found. Install: sudo apt install {missing}"}
    except Exception as e:
        return {"error": str(e)}


def parse_nmap_xml(xml_output):
    if not xml_output or not xml_output.strip():
        return {"error": "Empty nmap output — target may be unreachable or blocked by Tor exit node"}
    try:
        root = ET.fromstring(xml_output)
    except ET.ParseError as e:
        return {"error": f"Failed to parse nmap output: {e}"}

    results = {"scan_info": {}, "hosts": []}
    rs = root.find("runstats/finished")
    if rs is not None:
        results["scan_info"]["elapsed"] = rs.get("elapsed", "")
        results["scan_info"]["summary"] = rs.get("summary", "")

    for host in root.findall("host"):
        hd = {
            "ports": [], "os": None, "status": "unknown",
            "ip": "", "mac": "", "vendor": "", "hostnames": []
        }
        st = host.find("status")
        if st is not None:
            hd["status"] = st.get("state", "unknown")
        for addr in host.findall("address"):
            at = addr.get("addrtype", "")
            if at == "ipv4":
                hd["ip"] = addr.get("addr", "")
            elif at == "mac":
                hd["mac"] = addr.get("addr", "")
                hd["vendor"] = addr.get("vendor", "")
        hd["hostnames"] = [h.get("name", "") for h in host.findall("hostnames/hostname")]
        for om in host.findall("os/osmatch"):
            hd["os"] = om.get("name", "")
            hd["os_accuracy"] = om.get("accuracy", "")
            break
        for port in host.findall("ports/port"):
            state = port.find("state")
            if state is None or state.get("state") != "open":
                continue
            pd = {
                "port": int(port.get("portid", 0)),
                "protocol": port.get("protocol", "tcp"),
                "state": "open", "service": "", "product": "",
                "version": "", "extrainfo": "", "cpe": [], "scripts": {}
            }
            svc = port.find("service")
            if svc is not None:
                pd["service"] = svc.get("name", "")
                pd["product"] = svc.get("product", "")
                pd["version"] = svc.get("version", "")
                pd["extrainfo"] = svc.get("extrainfo", "")
                pd["cpe"] = [c.text for c in svc.findall("cpe") if c.text]
            for scr in port.findall("script"):
                pd["scripts"][scr.get("id", "")] = scr.get("output", "")
            hd["ports"].append(pd)
        results["hosts"].append(hd)

    return results


# ─── NETWORK DISCOVERY (via proxychains) ──────
def network_discovery(subnet):
    """
    Discover live hosts on a subnet through Tor/proxychains.
    NOTE: Host discovery is very limited through Tor — only TCP-based
    discovery works. ICMP ping is blocked.
    """
    try:
        cmd = [
            "proxychains4", "-q",
            "nmap",
            "-sT",          # TCP connect (proxychains requirement)
            "-Pn",          # No ping (ICMP blocked by Tor)
            "-n",           # No DNS
            "--open",
            "-T2",          # Polite timing
            "--host-timeout", "120s",
            "--max-retries", "1",
            "--top-ports", "10",   # Just check top 10 ports to detect hosts
            "-oX", "-",
            subnet
        ]
        print(f"[*] Network discovery via proxychains: {subnet}", file=sys.stderr)
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

        if not r.stdout.strip():
            return {"error": f"No output from nmap: {r.stderr.strip()[:200]}"}

        root = ET.fromstring(r.stdout)
        hosts = []
        for host in root.findall("host"):
            st = host.find("status")
            if st is None or st.get("state") != "up":
                continue
            hd = {"status": "up", "ip": "", "mac": "", "vendor": "", "hostnames": []}
            for addr in host.findall("address"):
                at = addr.get("addrtype", "")
                if at == "ipv4":
                    hd["ip"] = addr.get("addr", "")
                elif at == "mac":
                    hd["mac"] = addr.get("addr", "")
                    hd["vendor"] = addr.get("vendor", "")
            hd["hostnames"] = [h.get("name", "") for h in host.findall("hostnames/hostname")]
            if hd["ip"]:
                hosts.append(hd)

        return {"hosts": hosts, "total": len(hosts)}

    except subprocess.TimeoutExpired:
        return {"error": "Network discovery timed out. Subnet scanning through Tor is very slow."}
    except FileNotFoundError:
        return {"error": "proxychains4 or nmap not found. Install: sudo apt install proxychains4 nmap"}
    except Exception as e:
        return {"error": str(e)}


# ─── CVE LOOKUP (via Tor) ─────────────────────
NVD_API_KEY = ""  # Optional: free key from https://nvd.nist.gov/developers/request-an-api-key

def search_nvd_cves(product, version="", retries=3):
    """
    Query NVD for CVEs. Routes through Tor for anonymity.
    Increased timeout and retry delays for Tor latency.
    """
    if not product:
        return []
    try:
        kw = f"{product} {version}".strip()
        url = (f"https://services.nvd.nist.gov/rest/json/cves/2.0"
               f"?keywordSearch={urllib.parse.quote(kw)}&resultsPerPage=5")
        headers = {}
        if NVD_API_KEY:
            headers["apiKey"] = NVD_API_KEY

        for attempt in range(retries):
            try:
                with tor_urlopen(url, headers=headers, timeout=30) as resp:
                    data = json.loads(resp.read().decode())
                break
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    # Rate limit — Tor exit nodes share IP so rate limits hit faster
                    wait = 60 if not NVD_API_KEY else 10
                    print(f"[!] NVD rate limit — waiting {wait}s (attempt {attempt+1}/{retries})", file=sys.stderr)
                    time.sleep(wait)
                    continue
                return []
            except Exception as exc:
                print(f"[!] NVD attempt {attempt+1} failed: {exc}", file=sys.stderr)
                if attempt < retries - 1:
                    time.sleep(8)
                    continue
                return []

        cves = []
        for vuln in data.get("vulnerabilities", []):
            cve = vuln.get("cve", {})
            descs = cve.get("descriptions", [])
            desc = next((d["value"] for d in descs if d.get("lang") == "en"), "No description")
            metrics = cve.get("metrics", {})
            score, severity = None, "UNKNOWN"
            for mk in ["cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
                ml = metrics.get(mk, [])
                if ml:
                    cd = ml[0].get("cvssData", {})
                    score = cd.get("baseScore")
                    severity = ml[0].get("baseSeverity", cd.get("baseSeverity", "UNKNOWN"))
                    break
            has_exploit = any(
                "exploit" in r.get("url", "").lower() or "github" in r.get("url", "").lower()
                for r in cve.get("references", [])
            )
            cves.append({
                "id": cve.get("id", ""),
                "description": desc[:350] + "..." if len(desc) > 350 else desc,
                "score": score,
                "severity": severity,
                "has_exploit": has_exploit,
                "references": [r.get("url", "") for r in cve.get("references", [])[:3]],
                "published": cve.get("published", "")[:10]
            })
        return cves

    except Exception as e:
        print(f"[!] CVE lookup failed for {product}: {e}", file=sys.stderr)
        return []


# ─── SSL ANALYSIS (via Tor/SOCKS5) ────────────
def analyze_ssl(host, port=443):
    """
    Analyze SSL/TLS through Tor SOCKS5 proxy.
    Uses PySocks to connect through Tor before doing TLS handshake.
    """
    result = {"host": host, "port": port, "grade": "F", "issues": [], "details": {}}
    try:
        # Try SOCKS5 connection through Tor first
        try:
            import socks
            sock = socks.socksocket()
            sock.set_proxy(socks.SOCKS5, TOR_SOCKS_HOST, TOR_SOCKS_PORT)
            sock.settimeout(30)
            sock.connect((host, port))
        except ImportError:
            # Fallback to direct connection
            sock = socket.create_connection((host, port), timeout=30)

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with ctx.wrap_socket(sock, server_hostname=host) as ssock:
            cert = ssock.getpeercert()
            cipher = ssock.cipher()
            version = ssock.version()

            result["details"]["protocol"] = version
            result["details"]["cipher"] = cipher[0] if cipher else ""
            result["details"]["cipher_bits"] = cipher[2] if cipher else 0

            if cert:
                subject = dict(x[0] for x in cert.get("subject", []))
                issuer = dict(x[0] for x in cert.get("issuer", []))
                result["details"]["subject"] = subject.get("commonName", "")
                result["details"]["issuer"] = issuer.get("organizationName", "")
                exp = cert.get("notAfter", "")
                if exp:
                    try:
                        exp_dt = datetime.strptime(exp, "%b %d %H:%M:%S %Y %Z")
                        days_left = (exp_dt - datetime.utcnow()).days
                        result["details"]["expires"] = exp
                        result["details"]["days_until_expiry"] = days_left
                        if days_left < 0:
                            result["issues"].append({"severity": "CRITICAL", "msg": "Certificate EXPIRED"})
                        elif days_left < 30:
                            result["issues"].append({"severity": "HIGH", "msg": f"Expires in {days_left} days"})
                        elif days_left < 90:
                            result["issues"].append({"severity": "MEDIUM", "msg": f"Expires in {days_left} days"})
                    except Exception:
                        pass

            if version in ["TLSv1", "TLSv1.1", "SSLv2", "SSLv3"]:
                result["issues"].append({"severity": "HIGH", "msg": f"Weak protocol: {version}"})
            if cipher:
                cn = cipher[0].upper()
                if "RC4" in cn:
                    result["issues"].append({"severity": "CRITICAL", "msg": "RC4 cipher (broken)"})
                if "DES" in cn:
                    result["issues"].append({"severity": "CRITICAL", "msg": "DES cipher (broken)"})
                if "NULL" in cn:
                    result["issues"].append({"severity": "CRITICAL", "msg": "NULL cipher"})

            crit = sum(1 for i in result["issues"] if i["severity"] == "CRITICAL")
            high = sum(1 for i in result["issues"] if i["severity"] == "HIGH")
            if crit > 0:
                result["grade"] = "F"
            elif high > 0:
                result["grade"] = "C"
            elif len(result["issues"]) > 0:
                result["grade"] = "B"
            elif version == "TLSv1.3":
                result["grade"] = "A+"
            else:
                result["grade"] = "A"

    except ConnectionRefusedError:
        result["issues"].append({"severity": "INFO", "msg": f"Port {port} not open or SSL not available"})
        result["grade"] = "N/A"
    except socket.timeout:
        result["issues"].append({"severity": "INFO", "msg": f"SSL connection timed out on port {port} (Tor latency)"})
        result["grade"] = "N/A"
    except Exception as e:
        result["issues"].append({"severity": "INFO", "msg": f"SSL check: {str(e)}"})
        result["grade"] = "N/A"

    return result


# ─── DNS RECON ────────────────────────────────
def dns_recon(target):
    """
    DNS recon. dig queries go through system resolver (not Tor — DNS uses UDP).
    For anonymity, DNS queries are sent to a public resolver via proxychains if needed.
    """
    result = {
        "target": target, "records": {}, "issues": [],
        "subdomains": [], "has_spf": False, "has_dmarc": False
    }

    dig_available = False
    try:
        subprocess.run(["dig", "-v"], capture_output=True, timeout=3)
        dig_available = True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # DNS queries — use dig with increased timeout for proxychains if desired
    # Note: dig uses UDP which doesn't work through SOCKS, so we use direct DNS
    for rtype in ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"]:
        try:
            if dig_available:
                r = subprocess.run(
                    ["dig", "+short", "+time=10", "+tries=2", rtype, target],
                    capture_output=True, text=True, timeout=15
                )
                if r.stdout.strip():
                    result["records"][rtype] = [
                        l.strip() for l in r.stdout.strip().split("\n") if l.strip()
                    ]
            else:
                r = subprocess.run(
                    ["nslookup", "-type=" + rtype, target],
                    capture_output=True, text=True, timeout=15
                )
                lines = [l.strip() for l in r.stdout.split("\n") if l.strip() and "=" in l]
                if lines:
                    result["records"][rtype] = lines
        except Exception:
            pass

    if "A" not in result["records"]:
        try:
            ip = socket.gethostbyname(target)
            result["records"]["A"] = [ip]
        except Exception:
            pass

    txt = result["records"].get("TXT", [])
    result["has_spf"] = any("v=spf1" in t for t in txt)
    result["has_dmarc"] = any("v=DMARC1" in t for t in txt)
    if not result["has_spf"]:
        result["issues"].append({"severity": "HIGH", "msg": "No SPF record — email spoofing risk"})
    if not result["has_dmarc"]:
        result["issues"].append({"severity": "MEDIUM", "msg": "No DMARC record — email spoofing risk"})

    if dig_available:
        for ns in result["records"].get("NS", [])[:2]:
            try:
                r = subprocess.run(
                    ["dig", "axfr", target, f"@{ns.rstrip('.')}"],
                    capture_output=True, text=True, timeout=20
                )
                if "Transfer failed" not in r.stdout and len(r.stdout) > 200:
                    result["issues"].append({"severity": "CRITICAL", "msg": f"Zone transfer ALLOWED from {ns}"})
            except Exception:
                pass

    for sub in ["www", "mail", "ftp", "admin", "api", "dev", "staging", "test", "vpn",
                "smtp", "pop", "imap", "remote", "portal", "shop", "blog", "app",
                "cdn", "ns1", "ns2"]:
        try:
            fqdn = f"{sub}.{target}"
            socket.setdefaulttimeout(5)
            ip = socket.gethostbyname(fqdn)
            result["subdomains"].append({"subdomain": fqdn, "ip": ip})
        except Exception:
            pass

    if not dig_available:
        result["issues"].append({
            "severity": "INFO",
            "msg": "dig not found — install dnsutils: sudo apt-get install dnsutils"
        })

    return result


# ─── SUBDOMAIN FINDER ─────────────────────────
def subdomain_finder(domain, wordlist_size="medium"):
    """
    Subdomain enumeration. DNS brute-force uses direct DNS (UDP, not proxied).
    crt.sh and HackerTarget queries go through Tor.
    """
    result = {"domain": domain, "subdomains": [], "total": 0, "sources": []}
    found = {}

    small = ["www", "mail", "ftp", "admin", "api", "dev", "staging", "test", "vpn", "smtp",
             "pop3", "imap", "remote", "portal", "shop", "blog", "app", "cdn", "ns1", "ns2",
             "mx", "webmail", "cpanel", "whm", "autodiscover", "autoconfig", "mobile", "m",
             "static", "media", "img", "assets", "login", "secure", "beta", "alpha", "demo",
             "docs", "help", "support", "status", "monitor"]
    medium = small + ["git", "gitlab", "github", "jenkins", "jira", "confluence", "wiki", "kb",
                      "forum", "community", "chat", "slack", "teams", "meet", "video", "stream",
                      "api2", "v2", "v1", "old", "new", "backup", "bak", "temp", "tmp", "db",
                      "database", "mysql", "redis", "elastic", "search", "kibana", "grafana",
                      "prometheus", "vault", "consul", "etcd", "prod", "production", "stage",
                      "uat", "qa", "testing", "sandbox", "preview", "internal", "intranet",
                      "extranet", "private", "public", "external", "dmz"]
    wordlist = medium if wordlist_size == "medium" else small

    result["sources"].append("dns_bruteforce")
    for sub in wordlist:
        try:
            fqdn = f"{sub}.{domain}"
            socket.setdefaulttimeout(5)
            ips = socket.getaddrinfo(fqdn, None)
            ip = ips[0][4][0] if ips else ""
            if ip and fqdn not in found:
                found[fqdn] = {"subdomain": fqdn, "ip": ip, "source": "dns_bruteforce", "cname": ""}
        except Exception:
            pass

    # crt.sh — through Tor
    try:
        url = f"https://crt.sh/?q=%.{domain}&output=json"
        with tor_urlopen(url, timeout=45) as resp:
            certs = json.loads(resp.read().decode())
        result["sources"].append("crt.sh")
        for cert in certs[:200]:
            names = cert.get("name_value", "").split("\n")
            for name in names:
                name = name.strip().lower().lstrip("*.")
                if name.endswith(f".{domain}") or name == domain:
                    if name not in found:
                        try:
                            socket.setdefaulttimeout(5)
                            ip = socket.gethostbyname(name)
                            found[name] = {"subdomain": name, "ip": ip, "source": "crt.sh", "cname": ""}
                        except Exception:
                            found[name] = {"subdomain": name, "ip": "(not resolved)", "source": "crt.sh", "cname": ""}
    except Exception as e:
        print(f"[!] crt.sh lookup failed: {e}", file=sys.stderr)

    # HackerTarget — through Tor
    try:
        url = f"https://api.hackertarget.com/hostsearch/?q={domain}"
        with tor_urlopen(url, timeout=30) as resp:
            lines = resp.read().decode().strip().split("\n")
        result["sources"].append("hackertarget")
        for line in lines:
            if "," in line:
                parts = line.split(",")
                sub = parts[0].strip()
                ip = parts[1].strip() if len(parts) > 1 else ""
                if sub.endswith(f".{domain}") and sub not in found:
                    found[sub] = {"subdomain": sub, "ip": ip, "source": "hackertarget", "cname": ""}
    except Exception as e:
        print(f"[!] HackerTarget lookup failed: {e}", file=sys.stderr)

    result["subdomains"] = sorted(found.values(), key=lambda x: x["subdomain"])
    result["total"] = len(result["subdomains"])
    return result


# ─── DIRECTORY ENUMERATOR (via Tor) ───────────
def dir_enum(target_url, wordlist_size="small", extensions="php,html,txt,bak,zip"):
    """
    Directory busting through Tor SOCKS5.
    Reduced concurrency and longer timeouts due to Tor latency.
    """
    if not target_url.startswith("http"):
        target_url = "http://" + target_url
    target_url = target_url.rstrip("/")

    result = {"url": target_url, "found": [], "total": 0, "scanned": 0, "errors": 0}

    small_paths = [
        "admin", "login", "wp-admin", "administrator", "phpmyadmin", "dashboard", "panel",
        "cpanel", "webmail", "manager", "management", "console", "control", "portal",
        "api", "api/v1", "api/v2", "swagger", "docs", "documentation", "readme",
        "backup", "bak", "old", "temp", "tmp", ".git", "config", "configuration",
        "robots.txt", "sitemap.xml", ".env", "web.config", "phpinfo.php",
        "install", "setup", "update", "upgrade", "test", "debug", "info",
        "uploads", "upload", "files", "images", "static", "assets", "media",
        "wp-content", "wp-includes", "wp-login.php", "xmlrpc.php",
        "server-status", "server-info", ".htaccess", ".htpasswd",
        "user", "users", "account", "accounts", "profile", "register", "signup",
        "logout", "signout", "passwd", "password", "credentials",
        "shell", "cmd", "command", "exec", "execute", "run", "eval",
        "db", "database", "sql", "mysql", "sqlite", "mongo", "redis",
        "log", "logs", "error", "errors", "access", "audit", "trace",
        "404", "500", "error_log", "access_log", "debug.log", "app.log"
    ]
    medium_paths = small_paths + [
        "jenkins", "gitlab", "github", "jira", "confluence", "wiki",
        "grafana", "kibana", "elastic", "prometheus", "vault", "consul",
        "phpMyAdmin", "PMA", "pma", "myadmin", "dbadmin", "sqladmin",
        "wp-json", "wp-cron.php", "license.txt", "changelog.txt",
        "composer.json", "package.json", ".gitignore", ".DS_Store",
        "Thumbs.db", "desktop.ini", "web.config.bak", "web.config.old",
        "application", "app", "apps", "service", "services", "rest", "soap",
        "v1", "v2", "v3", "health", "status", "ping", "metrics", "monitor",
        "secret", "secrets", "private", "hidden", "internal", "dev", "staging",
        "cgi-bin", "scripts", "bin", "lib", "include", "includes", "src",
        "classes", "models", "views", "controllers", "helpers", "utils",
        "index.php", "index.html", "index.asp", "index.aspx", "default.asp",
        "home", "main", "welcome", "start", "begin", "init", "bootstrap"
    ]
    paths = medium_paths if wordlist_size == "medium" else small_paths
    exts = [""] + [f".{e.strip()}" for e in extensions.split(",") if e.strip()]

    all_paths = []
    for path in paths:
        if "." in path.split("/")[-1]:
            all_paths.append(path)
        else:
            for ext in exts:
                all_paths.append(path + ext)

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    print(f"[*] Dir enum via Tor: {target_url} ({len(all_paths[:300])} paths)", file=sys.stderr)

    for path in all_paths[:300]:  # Reduced from 500 — Tor makes this slow
        url = f"{target_url}/{path}"
        try:
            # Use Tor for dir busting
            with tor_urlopen(url, timeout=15) as resp:  # 15s timeout per request
                status = resp.status
                length = resp.headers.get("Content-Length", "?")
                content_type = resp.headers.get("Content-Type", "").split(";")[0]
                if status in [200, 201, 204, 301, 302, 307, 308, 401, 403]:
                    severity = "HIGH" if status == 200 else (
                        "MEDIUM" if status in [301, 302, 307, 308] else "LOW"
                    )
                    if any(s in path for s in [
                        "admin", "shell", "config", "backup", ".env",
                        "passwd", "sql", "git", "debug", "log"
                    ]):
                        severity = "CRITICAL" if status == 200 else "HIGH"
                    result["found"].append({
                        "url": url, "status": status, "size": length,
                        "type": content_type, "severity": severity,
                        "note": get_dir_note(path, status)
                    })
            result["scanned"] += 1
        except urllib.error.HTTPError as e:
            if e.code in [401, 403]:
                result["found"].append({
                    "url": url, "status": e.code, "size": "?",
                    "type": "", "severity": "MEDIUM",
                    "note": "Access restricted — resource exists"
                })
            result["scanned"] += 1
        except Exception:
            result["errors"] += 1
            result["scanned"] += 1

        # Small delay between requests through Tor to avoid circuit overload
        time.sleep(0.1)

    result["total"] = len(result["found"])
    result["found"].sort(
        key=lambda x: {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}.get(x.get("severity", "LOW"), 3)
    )
    return result


def get_dir_note(path, status):
    notes = {
        ".git": "Git repository exposed — source code may be accessible",
        ".env": "Environment file exposed — credentials may be visible",
        "phpinfo": "PHP configuration exposed",
        "phpmyadmin": "phpMyAdmin exposed — database admin interface",
        "wp-admin": "WordPress admin panel",
        "backup": "Backup file/directory found",
        ".htpasswd": "Password file exposed",
        "config": "Configuration file found",
        "admin": "Admin panel found",
        "shell": "Potential shell/command execution endpoint",
        "passwd": "Password file found",
        "sql": "Database file/endpoint found",
        "debug": "Debug interface exposed",
        "log": "Log file accessible",
        "robots.txt": "Robots.txt — check for hidden paths",
        ".DS_Store": "macOS metadata file — directory structure exposed",
        "composer.json": "Dependency file exposed — reveals technology stack",
    }
    for k, v in notes.items():
        if k in path.lower():
            return v
    if status == 401:
        return "Authentication required"
    if status == 403:
        return "Forbidden — resource exists but access denied"
    if status in [301, 302]:
        return "Redirect found"
    return "Resource found"


# ─── LOGIN BRUTE FORCE (via Tor) ──────────────
def brute_force_http(url, usernames, passwords, user_field="username", pass_field="password"):
    """
    HTTP brute force through Tor. Tor provides IP anonymity but slows requests.
    Added longer sleep between attempts to avoid Tor circuit bans.
    """
    result = {"url": url, "attempts": 0, "found": [], "status": "running"}

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    for username in usernames[:10]:
        for password in passwords[:50]:
            try:
                data = urllib.parse.urlencode({
                    user_field: username,
                    pass_field: password
                }).encode()

                with tor_urlopen(url, timeout=20, data=data) as resp:
                    body = resp.read().decode(errors="ignore")
                    fail_kw = ["invalid", "incorrect", "wrong", "failed", "error",
                               "denied", "bad credentials", "unauthorized"]
                    success_kw = ["dashboard", "welcome", "logout", "profile",
                                  "account", "success"]
                    body_lower = body.lower()
                    is_fail = any(k in body_lower for k in fail_kw)
                    is_success = any(k in body_lower for k in success_kw)
                    if is_success and not is_fail:
                        result["found"].append({
                            "username": username,
                            "password": password,
                            "status": resp.status
                        })
                result["attempts"] += 1
                time.sleep(0.5)  # Slightly longer delay through Tor
            except Exception:
                result["attempts"] += 1

    result["status"] = "complete"
    return result


def brute_force_ssh(host, port, usernames, passwords):
    """
    SSH brute force. SSH can be proxied through Tor using paramiko + SOCKS5.
    """
    result = {"host": host, "port": port, "attempts": 0, "found": [], "status": "running", "note": ""}
    try:
        import paramiko
        for username in usernames[:5]:
            for password in passwords[:20]:
                try:
                    client = paramiko.SSHClient()
                    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

                    # Try to route SSH through Tor SOCKS5
                    try:
                        import socks
                        proxy_sock = socks.socksocket()
                        proxy_sock.set_proxy(socks.SOCKS5, TOR_SOCKS_HOST, TOR_SOCKS_PORT)
                        proxy_sock.settimeout(30)
                        proxy_sock.connect((host, int(port)))
                        client.connect(
                            host, port=int(port),
                            username=username, password=password,
                            timeout=30, banner_timeout=30,
                            sock=proxy_sock
                        )
                    except ImportError:
                        # Fallback: direct connection
                        client.connect(
                            host, port=int(port),
                            username=username, password=password,
                            timeout=30, banner_timeout=30
                        )

                    result["found"].append({"username": username, "password": password})
                    client.close()
                except paramiko.AuthenticationException:
                    pass
                except Exception:
                    break
                result["attempts"] += 1
                time.sleep(0.5)
        result["status"] = "complete"
    except ImportError:
        result["status"] = "error"
        result["note"] = "paramiko not installed: pip3 install paramiko --break-system-packages"
    return result


# ─── WEB HEADERS (via Tor) ────────────────────
def analyze_web_headers(target):
    """
    Fetch HTTP headers through Tor SOCKS5 proxy.
    Increased timeout for Tor latency.
    """
    result = {
        "url": "", "status_code": None, "headers": {}, "issues": [],
        "score": 0, "grade": "F", "server": "", "technologies": []
    }
    for scheme in ["https", "http"]:
        url = f"{scheme}://{target}" if not target.startswith("http") else target
        try:
            with tor_urlopen(url, timeout=30) as resp:
                result["url"] = url
                result["status_code"] = resp.status
                headers = dict(resp.headers)
                result["headers"] = headers
                server = headers.get("Server", "")
                result["server"] = server
                if server:
                    result["technologies"].append(server)
                    if re.search(r'\d+\.\d+', server):
                        result["issues"].append({
                            "severity": "MEDIUM",
                            "msg": f"Server version disclosed: {server}"
                        })
                xpb = headers.get("X-Powered-By", "")
                if xpb:
                    result["technologies"].append(xpb)
                    result["issues"].append({"severity": "LOW", "msg": f"X-Powered-By disclosed: {xpb}"})
                score = 100
                checks = [
                    ("Strict-Transport-Security", "HSTS not set — HTTPS downgrade risk", "HIGH"),
                    ("Content-Security-Policy", "No CSP — XSS risk", "HIGH"),
                    ("X-Frame-Options", "No X-Frame-Options — Clickjacking risk", "MEDIUM"),
                    ("X-Content-Type-Options", "No X-Content-Type-Options — MIME sniffing risk", "MEDIUM"),
                    ("Referrer-Policy", "No Referrer-Policy", "LOW"),
                    ("Permissions-Policy", "No Permissions-Policy", "LOW"),
                ]
                hdr_lower = {k.lower() for k in headers}
                for hdr, msg, sev in checks:
                    if hdr.lower() not in hdr_lower:
                        result["issues"].append({"severity": sev, "msg": msg})
                        score -= {"HIGH": 20, "MEDIUM": 10, "LOW": 5}[sev]
                result["score"] = max(0, score)
                if score >= 90:   result["grade"] = "A+"
                elif score >= 75: result["grade"] = "A"
                elif score >= 60: result["grade"] = "B"
                elif score >= 45: result["grade"] = "C"
                elif score >= 30: result["grade"] = "D"
                else:             result["grade"] = "F"
                break
        except Exception as e:
            result["issues"].append({"severity": "INFO", "msg": f"Could not fetch {url}: {str(e)}"})
    return result


# ─── MITIGATIONS & RISK ───────────────────────
def get_mitigation_advice(service, product, cves):
    advice = []
    sl = (service or "").lower()
    pl = (product or "").lower()
    svc_advice = {
        "ssh": ["Disable root login (PermitRootLogin no)", "Use SSH key authentication",
                "Change default port 22", "Deploy fail2ban", "Restrict to specific IPs"],
        "http": ["Enable HTTPS, redirect all HTTP", "Implement CSP headers",
                 "Add X-Frame-Options", "Keep web server updated", "Disable directory listing"],
        "https": ["Ensure TLS 1.2+ only", "Use ECDHE/AES-GCM ciphers", "Enable HSTS", "Renew certs before expiry"],
        "ftp": ["Replace FTP with SFTP/FTPS", "Disable anonymous access", "Use chroot jail"],
        "smtp": ["Enable SMTP auth", "Implement SPF, DKIM, DMARC", "Use TLS"],
        "mysql": ["Never expose to internet", "Bind to localhost only", "Least privilege", "Enable audit logging"],
        "postgresql": ["Restrict via pg_hba.conf", "Use SSL for remote connections", "Enable query logging"],
        "rdp": ["Enable NLA", "Use VPN", "Account lockout policy", "Change default port 3389", "Require MFA"],
        "smb": ["Disable SMBv1 immediately", "Enable SMB signing", "Block ports 445/139"],
        "telnet": ["DISABLE TELNET — plaintext protocol", "Replace with SSH", "Block port 23"],
        "vnc": ["Never expose VNC publicly", "Use VPN or SSH tunnel", "Enable VNC password auth"],
        "redis": ["Bind to localhost only", "Enable AUTH password", "Never expose publicly"],
        "mongodb": ["Enable authentication", "Bind to localhost", "Use TLS", "Enable audit logging"],
    }
    for svc, tips in svc_advice.items():
        if svc in sl or svc in pl:
            advice.extend(tips)
            break
    if not advice:
        advice = [
            f"Keep {product or service} updated to latest version",
            "Apply principle of least privilege",
            "Monitor service logs for suspicious activity",
            "Restrict access to authorized hosts only"
        ]
    critical = [c for c in cves if c.get("severity") in ["CRITICAL", "HIGH"]]
    if critical:
        advice.insert(0, f"URGENT: {len(critical)} critical/high CVEs — patch immediately")
    advice.extend(["Implement IDS/IPS monitoring", "Schedule regular vulnerability scans"])
    return advice[:8]


def calculate_risk(cves, port, service):
    high_risk = {21, 22, 23, 25, 80, 443, 445, 1433, 1521, 3306, 3389, 5432, 5900, 6379, 27017}
    base = 0
    if cves:
        base = max((c.get("score") or 0) for c in cves)
        if any(c.get("has_exploit") for c in cves):
            base = min(10, base + 1)
    elif port in high_risk:
        base = 5.0
    else:
        base = 2.0
    if service and service.lower() == "telnet":
        base = 9.5
    if base >= 9.0:   level = "CRITICAL"
    elif base >= 7.0: level = "HIGH"
    elif base >= 4.0: level = "MEDIUM"
    elif base > 0:    level = "LOW"
    else:             level = "UNKNOWN"
    return round(base, 1), level


# ─── FULL SCAN ORCHESTRATOR ───────────────────
def full_scan(target, modules=None):
    """
    Orchestrates all scan modules.
    CVE lookups are rate-limited more conservatively since Tor exit nodes
    share IP addresses and may hit NVD rate limits faster.
    """
    if modules is None:
        modules = ["ports", "ssl", "dns", "headers"]

    result = {"target": target, "scan_time": datetime.utcnow().isoformat(), "modules": {}}

    scan = run_nmap_scan(target)
    if "error" in scan:
        result["modules"]["ports"] = scan
        result["summary"] = {
            "total_cves": 0, "critical_cves": 0,
            "high_cves": 0, "exploitable": 0, "open_ports": 0
        }
        result["error"] = scan["error"]
        return result

    # CVE lookups — throttled more aggressively for Tor (shared exit node IPs)
    for host in scan.get("hosts", []):
        for port in host.get("ports", []):
            svc = port.get("service", "")
            prod = port.get("product", "")
            ver = port.get("version", "")
            cves = []
            if prod:
                cves = search_nvd_cves(prod, ver)
                # Tor exit nodes share IPs — be generous with rate limit waits
                time.sleep(2 if NVD_API_KEY else 8)
            if not cves and svc:
                cves = search_nvd_cves(svc, ver)
                time.sleep(2 if NVD_API_KEY else 8)
            port["cves"] = cves
            port["mitigations"] = get_mitigation_advice(svc, prod, cves)
            port["risk_score"], port["risk_level"] = calculate_risk(cves, port["port"], svc)

    result["modules"]["ports"] = scan
    clean = re.sub(r'https?://', '', target).split('/')[0]

    if "ssl" in modules:
        ssl_ports = [443, 8443, 465, 993, 995]
        if "hosts" in scan:
            open_ports = [p["port"] for h in scan.get("hosts", []) for p in h.get("ports", [])]
            matched = [p for p in ssl_ports if p in open_ports]
            ssl_ports = matched if matched else [443]
        ssl_results = []
        for sp in ssl_ports[:2]:
            sr = analyze_ssl(clean, sp)
            if sr.get("grade") != "N/A":
                ssl_results.append(sr)
        result["modules"]["ssl"] = ssl_results if ssl_results else [analyze_ssl(clean, 443)]

    if "dns" in modules:
        result["modules"]["dns"] = dns_recon(clean)

    if "headers" in modules:
        result["modules"]["headers"] = analyze_web_headers(clean)

    all_cves = [
        c for h in scan.get("hosts", [])
        for p in h.get("ports", [])
        for c in p.get("cves", [])
    ]
    result["summary"] = {
        "total_cves": len(all_cves),
        "critical_cves": sum(1 for c in all_cves if c.get("severity") == "CRITICAL"),
        "high_cves": sum(1 for c in all_cves if c.get("severity") == "HIGH"),
        "exploitable": sum(1 for c in all_cves if c.get("has_exploit")),
        "open_ports": sum(len(h.get("ports", [])) for h in scan.get("hosts", []))
    }
    return result


# ─── JOHN THE RIPPER ──────────────────────────
def john_the_ripper(hash_input, hash_format="", wordlist="", mode="wordlist", extra_options=""):
    import shutil, tempfile, os as _os
    result = {
        "mode": mode, "hash_format": hash_format or "auto-detect",
        "cracked": [], "total_hashes": 0, "status": "running", "output": "", "note": ""
    }
    binary = shutil.which("john") or shutil.which("john-the-ripper")
    if not binary:
        result["status"] = "error"
        result["note"] = "John the Ripper not installed. Run: sudo apt-get install john"
        return result

    hash_file = hash_input.strip()
    tmp_file = None
    if not _os.path.isfile(hash_file):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tf:
            tf.write(hash_input.strip() + "\n")
            tmp_file = tf.name
        hash_file = tmp_file

    with open(hash_file) as f:
        result["total_hashes"] = sum(1 for line in f if line.strip())

    cmd = [binary]
    if hash_format:
        cmd += [f"--format={hash_format}"]
    if mode == "wordlist":
        wl = wordlist if wordlist and _os.path.isfile(wordlist) else "/usr/share/wordlists/rockyou.txt"
        if not _os.path.isfile(wl):
            for fallback in ["/usr/share/john/password.lst", "/usr/share/dict/words"]:
                if _os.path.isfile(fallback):
                    wl = fallback
                    break
            else:
                result["status"] = "error"
                result["note"] = "Wordlist not found. Install: sudo apt-get install wordlists"
                if tmp_file: _os.unlink(tmp_file)
                return result
        cmd += [f"--wordlist={wl}"]
    elif mode == "rules":
        wl = wordlist if wordlist and _os.path.isfile(wordlist) else "/usr/share/wordlists/rockyou.txt"
        cmd += [f"--wordlist={wl}", "--rules"]
    elif mode == "incremental":
        cmd += ["--incremental"]
    elif mode == "single":
        cmd += ["--single"]
    elif mode == "show":
        cmd += ["--show"]

    SAFE_EXTRA = re.compile(
        r'^--(min-length=\d+|max-length=\d+|fork=\d+|node=\d+/\d+|session=\w+|restore=\w*|pot=[\w/.-]+)$'
    )
    for opt in extra_options.split():
        if SAFE_EXTRA.match(opt):
            cmd.append(opt)
    cmd.append(hash_file)

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        raw_out = proc.stdout + "\n" + proc.stderr
        result["output"] = raw_out[:3000]
        show_cmd = [binary, "--show", hash_file]
        if hash_format:
            show_cmd.insert(1, f"--format={hash_format}")
        show_proc = subprocess.run(show_cmd, capture_output=True, text=True, timeout=30)
        for line in show_proc.stdout.splitlines():
            if ":" in line and not line.startswith("#"):
                parts = line.split(":")
                if len(parts) >= 2 and parts[1]:
                    result["cracked"].append({
                        "hash": parts[0], "password": parts[1],
                        "extra": ":".join(parts[2:]) if len(parts) > 2 else ""
                    })
        m = re.search(r'(\d+)\s+password\s+hash(?:es)?\s+cracked', raw_out, re.IGNORECASE)
        cracked_count = int(m.group(1)) if m else len(result["cracked"])
        result["status"] = "complete"
        result["cracked_count"] = cracked_count
        result["note"] = (
            f"{cracked_count} of {result['total_hashes']} hash(es) cracked."
            if cracked_count else
            "No hashes cracked. Try a different mode, wordlist, or format."
        )
    except subprocess.TimeoutExpired:
        result["status"] = "timeout"
        result["note"] = "John the Ripper timed out after 5 minutes."
    except Exception as e:
        result["status"] = "error"
        result["note"] = str(e)
    finally:
        if tmp_file and _os.path.exists(tmp_file):
            _os.unlink(tmp_file)

    return result


# ─── ENTRY POINT ──────────────────────────────
if __name__ == "__main__":
    import os

    if len(sys.argv) < 2:
        print(json.dumps({"error": "No target specified"}))
        sys.exit(1)

    if "--discover" in sys.argv:
        idx = sys.argv.index("--discover")
        print(json.dumps(network_discovery(sys.argv[idx + 1])))
        sys.exit(0)

    if "--subdomains" in sys.argv:
        idx = sys.argv.index("--subdomains")
        size = sys.argv[idx + 2] if len(sys.argv) > idx + 2 else "medium"
        print(json.dumps(subdomain_finder(sys.argv[idx + 1], size)))
        sys.exit(0)

    if "--dirbust" in sys.argv:
        idx = sys.argv.index("--dirbust")
        size = sys.argv[idx + 2] if len(sys.argv) > idx + 2 else "small"
        exts = sys.argv[idx + 3] if len(sys.argv) > idx + 3 else "php,html,txt"
        print(json.dumps(dir_enum(sys.argv[idx + 1], size, exts)))
        sys.exit(0)

    if "--brute-http" in sys.argv:
        idx = sys.argv.index("--brute-http")
        url = sys.argv[idx + 1]
        users = sys.argv[idx + 2].split(",")
        pwds = sys.argv[idx + 3].split(",")
        uf = sys.argv[idx + 4] if len(sys.argv) > idx + 4 else "username"
        pf = sys.argv[idx + 5] if len(sys.argv) > idx + 5 else "password"
        print(json.dumps(brute_force_http(url, users, pwds, uf, pf)))
        sys.exit(0)

    if "--brute-ssh" in sys.argv:
        idx = sys.argv.index("--brute-ssh")
        host = sys.argv[idx + 1]
        port = sys.argv[idx + 2]
        users = sys.argv[idx + 3].split(",")
        pwds = sys.argv[idx + 4].split(",")
        print(json.dumps(brute_force_ssh(host, port, users, pwds)))
        sys.exit(0)

    if "--john" in sys.argv:
        idx = sys.argv.index("--john")
        hash_input  = sys.argv[idx + 1] if len(sys.argv) > idx + 1 else ""
        hash_format = sys.argv[idx + 2] if len(sys.argv) > idx + 2 else ""
        wordlist    = sys.argv[idx + 3] if len(sys.argv) > idx + 3 else ""
        mode        = sys.argv[idx + 4] if len(sys.argv) > idx + 4 else "wordlist"
        extra       = sys.argv[idx + 5] if len(sys.argv) > idx + 5 else ""
        print(json.dumps(john_the_ripper(hash_input, hash_format, wordlist, mode, extra)))
        sys.exit(0)

    mods = ["ports", "ssl", "dns", "headers"]
    target = sys.argv[-1]
    if "--modules" in sys.argv:
        idx = sys.argv.index("--modules")
        mods = sys.argv[idx + 1].split(",")

    print(json.dumps(full_scan(target, mods)))
